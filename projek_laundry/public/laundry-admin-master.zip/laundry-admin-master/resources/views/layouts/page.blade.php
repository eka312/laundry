@extends('adminlte::page')

@push('css')
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
@endpush
