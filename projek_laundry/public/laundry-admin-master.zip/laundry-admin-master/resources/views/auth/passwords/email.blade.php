@extends('adminlte::passwords.email')

@section('css')
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
@stop

@include('components.unsplash_credits')
